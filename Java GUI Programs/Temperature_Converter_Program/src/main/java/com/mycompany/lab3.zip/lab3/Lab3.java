/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab3;

/**
 *
 * @author Gibby
 */
public class Lab3 {

    public static void main(String[] args) {
        TempGui tempy = new TempGui();
        tempy.setVisible(true);
                
    }
}
